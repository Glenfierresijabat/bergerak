class Catatan {
  String judul;
  String ini;
  DateTime? tglinput;

  Catatan({
    required this.judul,
    required this.ini,
  }) {
    tglinput = DateTime.now();
  }
}
