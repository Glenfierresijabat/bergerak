import 'package:aplikasi1/catatan.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  TextEditingController judulCtr = TextEditingController();
  TextEditingController isiCtr = TextEditingController();
  List<Catatan> listCatatan = [];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('catatan pagi'),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(children: [
            TextField(
                controller: judulCtr,
                decoration: InputDecoration(hintText: "judul catatan")),
            TextField(
                controller: isiCtr,
                decoration: InputDecoration(hintText: "ini catatan")),
            Row(
              children: [
                ElevatedButton(
                    onPressed: () {
                      judulCtr.clear();
                      isiCtr.clear();
                    },
                    child: Text("clear")),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        listCatatan.add(
                            Catatan(judul: judulCtr.text, ini: isiCtr.text));
                      });
                    },
                    child: Text("submit"))
              ],
            ),
            Expanded(
                child: ListView.builder(
              itemCount: 10,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text("catatan $index"),
                  subtitle: Text("isi catatan"),
                );
              },
            ))
          ]),
        ),
      ),
    );
  }
}
